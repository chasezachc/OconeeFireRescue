package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VerifyLogin {
	
	private Connection connection;
	private boolean results;
	
	//Creates connection to database
	public VerifyLogin(String databaseName, String username, String password){
		String url = "jdbc:mysql://localhost:3306/" + databaseName;
		
		//Set up driver
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.connection = DriverManager.getConnection(url, username, password);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			System.out.println("1");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("2");
			e.printStackTrace();
		}
		
	}
	
	//Takes given email and password. Checks if it is in the database. Returns boolean indicating results.
	public boolean checkDatabase(String submittedEmail, String submittedPassword){
		//String query = "select * from User where email=\"?\" and password=\"?\"";
		String query = "select * from User where email=? and password=?";
		
		try {
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setString(1, submittedEmail);
			ps.setString(2, submittedPassword);
			
			ResultSet resultSet = ps.executeQuery();
			
			this.results = resultSet.first();
			
		} catch (SQLException e) {
			System.out.println("3");
			e.printStackTrace();
		}
		
		return results;
	}

}
