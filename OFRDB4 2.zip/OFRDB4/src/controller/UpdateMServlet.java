package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbhelper.UpdateMQuery;
import model.Person;

/**
 * Servlet implementation class UpdateMServlet
 */
@WebServlet("/UpdateMServlet")
public class UpdateMServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateMServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int employeeID = Integer.parseInt(request.getParameter("employeeID"));
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String radio = request.getParameter("radio");
		String station = request.getParameter("station");
		String active = request.getParameter("active");
		String address = request.getParameter("address");
		int work = Integer.parseInt(request.getParameter("work"));
		int mobile = Integer.parseInt(request.getParameter("mobile"));
		Person person = new Person();
		person.setEmployeeID(employeeID);
		person.setFirstName(firstName);
		person.setLastName(lastName);
		person.setRadioNumber(radio);
		person.setStationNumber(station);
		person.setActive(active);
		person.setAddress(address);
		person.setWorkPhone(work);
		person.setMobilePhone(mobile);
		UpdateMQuery umq = new UpdateMQuery("FRDB","root","Trumpet");
		umq.doUpdate(person);
		String url = "/DefaultServlet";
		RequestDispatcher d = request.getRequestDispatcher(url);
		d.forward(request, response);
	}

}
