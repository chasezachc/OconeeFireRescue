package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbhelper.AddMQuery;
import model.Person;

/**
 * Servlet implementation class AddMServlet
 */
@WebServlet("/AddMServlet")
public class AddMServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddMServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String first = request.getParameter("fn");
		String last = request.getParameter("ln");
		String radio = request.getParameter("radio");
		String station = request.getParameter("station");
		String active = request.getParameter("active");
		String address = request.getParameter("address");
		String work = request.getParameter("work");
		String mobile = request.getParameter("mobile");
		String email = request.getParameter("email");
		String gender = request.getParameter("gender");
		String dob = request.getParameter("dob");
		String position = request.getParameter("position");
		Person person = new Person();
		person.setFirstName(first);
		person.setLastName(last);
		person.setRadioNumber(radio);
		person.setStationNumber(station);
		person.setActive(active);
		person.setAddress(address);
		person.setWorkPhone(Integer.parseInt(work));
		person.setMobilePhone(Integer.parseInt(mobile));
		person.setEmail(email);
		person.setGender(gender);
		person.setDob(dob);
		person.setPosition(position);
		AddMQuery amq = new AddMQuery("FRDB","root","Trumpet");
		amq.addM(person);
		
		
	}

}
