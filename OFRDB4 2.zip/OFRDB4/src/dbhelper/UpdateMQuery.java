package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Person;

public class UpdateMQuery {

	private Connection connection;

	public UpdateMQuery(String db, String un, String pwd){
		String url="jdbc:mysql://localhost:3306/" + db;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.connection = DriverManager.getConnection(url, un, pwd);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void doUpdate(Person person){
		String query = "update Person set firstName=?,lastName=?,radioNumber=?,stationNumber=?,active=?,address=?,workPhone=?,mobilePhone=? where employeeID=?";
		try {
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setInt(9, person.getEmployeeID());
			ps.setString(1, person.getFirstName());
			ps.setString(2, person.getLastName());
			ps.setString(3, person.getRadioNumber());
			ps.setString(4, person.getStationNumber());
			ps.setString(5, person.isActive());
			ps.setString(6, person.getAddress());
			ps.setInt(7, person.getMobilePhone());
			ps.setInt(8, person.getWorkPhone());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
