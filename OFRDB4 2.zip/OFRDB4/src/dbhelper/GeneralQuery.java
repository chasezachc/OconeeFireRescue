package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Certificate;
import model.Person;

public class GeneralQuery {

	private Connection c;
	ResultSet personResults, certResults;

	public GeneralQuery(String db, String un, String pwd){
		String url = "jdbc:mysql://localhost:3306/" + db;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.c = DriverManager.getConnection(url, un, pwd);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			System.out.println("1");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("2");
			e.printStackTrace();
		}
	}

	public ResultSet getPersonResults(){
		return personResults;
	}
	
	public String getCSVTable(ResultSet results){
		String table ="";
		
		try {
			while(results.next()) {

				Person person = new Person(results.getString("stationNumber"),results.getString("radioNumber"),results.getString("email")
						);
				
				// Because we can't put the " character easily inside a 
				// String, we "escape" it by using a backslash sequence.
				// The \" sequence is resolved by Java to mean the " character
				
				// The CSV format wraps strings in double quotes.
				// Any double quotes already part of the string need to be
				// doubled up according to the CSV specification.
				// Thus, " turns in to "" in CSV to indicate the field contains
				// a double quote character.

				table += "\"";
				table += person.getStationNumber().replaceAll("\"", "\"\"");
				table +="\", \"";
				table += person.getRadioNumber().replaceAll("\"", "\"\"");
				table +="\",";
				table += person.getEmail().replaceAll("\"","\"\"");
				table +="\n";  // Important!

				// Just as \" is resolved as a " character, \n resolves
				// as a new line. Each record in a CSV file is a new line.
			}
		} catch (SQLException e) {
			System.out.println("THE MISTAKE");// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return table;
	}
	
	public String makeMainPage(){
		makePersonResults();
		String table = "";
		table += "<table border = 1>";
		table += "<tr>";
		table += "<td>";
		table += "First Name";
		table += "</td>";
		table += "<td>";
		table += "Last Name";
		table += "</td>";
		table += "<td>";
		table += "Radio Number";
		table += "</td>";
		table += "<td>";
		table += "Station Number";
		table += "</td>";
		table += "<td>";
		table += "Active";
		table += "</td>";
		table += "<td>";
		table += "Address";
		table += "</td>";
		table += "<td>";
		table += "Work Phone";
		table += "</td>";
		table += "<td>";
		table += "Modile Phone";
		table += "</td>";
		table += "<td>";
		table += "Employee ID";
		table += "</td>";
		table += "<td>";
		table += "Certificates";
		table += "</td>";
		table += "<td>";
		table += "Update or Delete Employee";
		table += "</td>";
		table += "</tr>";
		try {
			while(this.personResults.next()){
				Person person = new Person();
				person.setEmployeeID(this.personResults.getInt("employeeID"));
				person.setFirstName(this.personResults.getString("firstName"));
				person.setLastName(this.personResults.getString("lastName"));
				person.setRadioNumber(this.personResults.getString("radioNumber"));
				person.setStationNumber(this.personResults.getString("stationNumber"));
				person.setActive(this.personResults.getString("active"));
				person.setAddress(this.personResults.getString("address"));
				person.setWorkPhone(this.personResults.getInt("workPhone"));
				person.setMobilePhone(this.personResults.getInt("mobilePhone"));
				makeCertResults(person);
				table += "<tr>";
				table += "<td>";
				table += person.getFirstName();
				table += "</td>";
				table += "<td>";
				table += person.getLastName();
				table += "</td>";
				table += "<td>";
				table += person.getRadioNumber();
				table += "</td>";
				table += "<td>";
				table += person.getStationNumber();
				table += "</td>";
				table += "<td>";
				table += person.isActive();
				table += "</td>";
				table += "<td>";
				table += person.getAddress();
				table += "</td>";
				table += "<td>";
				table += person.getWorkPhone();
				table += "</td>";
				table += "<td>";
				table += person.getMobilePhone();
				table += "</td>";
				table += "<td>";
				table += person.getEmployeeID();
				table += "</td>";
				table += "<td>";
				//table += "<a href=CertificateTableServlet?employeeID=" + person.getEmployeeID() + ">View Certificates</a>";
				table += "<table>";
				while(this.certResults.next()){
					Certificate certificate = new Certificate();
					certificate.setCertificateID(this.certResults.getInt("certificateID"));
					certificate.setName(this.certResults.getString("name"));
					certificate.setDescription(this.certResults.getString("description"));
					certificate.setExpiryLength(this.certResults.getInt("years"));
					certificate.setLastRenewed(this.certResults.getDate("lastRenewed"));
					table += "<tr>";
					table += "<td>";
					table += certificate.getName();
					table += "</td>";
					table += "<td>";
					table += certificate.getDescription();
					table += "</td>";
					table += "<td>";
					table += certificate.getExpiryLength();
					table += "</td>";
					table += "<td>";
					table += certificate.getLastRenewed();
					table += "</td>";
					table += "<td>";
					table += "<a href=UpdateCFormServlet?eID=" + person.getEmployeeID() + "&cID=" + certificate.getCertificateID() + ">Update</a>";
					table += "</td>";
					table += "<td>";
					table += "<a href=DeleteCServlet?eID=" + person.getEmployeeID() + "&cID=" + certificate.getCertificateID() + ">Delete</a>";
					table += "</td>";
					table += "</tr>";
				}
				table += "</table>";
				table += "<a href=AddCFormServlet?eID=" + person.getEmployeeID() + ">Add Certificate</a>";
				table += "</td>";
				table += "<td>";
				table += "<a href=UpdateMFormServlet?eID=" + person.getEmployeeID() + ">update</a> <a href=DeleteMServlet?eID=" + person.getEmployeeID() + ">delete</a>";
				table += "</td>";
				table += "</tr>";
			}
		} catch (SQLException e) {
			System.out.println("Loop creating HTML for Table failed");
			e.printStackTrace();
		}
		table += "</table><br>";
		table += "<a href=AddMFormServlet>Add Member</a>";
		return table;
	}
	
	/*public String getCSVTable(ResultSet results){
		
	}*/
	
	public void makePersonResults(){
		String query = "select * from Person";
		try {
			PreparedStatement ps = this.c.prepareStatement(query);
			this.personResults = ps.executeQuery();

		} catch (SQLException e) {
			System.out.println("Failed to receive full list of Persons from DB");
			e.printStackTrace();
		}	
	}
	
	public void makeCertResults(Person person){
		String query = "select * from Person_Certificate, Certificate where Person_Certificate.employeeID=? and Person_Certificate.certificateID = Certificate.certificateID";
		
		try {
			PreparedStatement ps = this.c.prepareStatement(query);
			ps.setInt(1, person.getEmployeeID());
			this.certResults = ps.executeQuery();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
