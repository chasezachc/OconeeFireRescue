package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CheckLogin {
	
	private Connection c;
	private boolean results;
	
	public CheckLogin(String db, String un, String pwd){
		String url = "jdbc:mysql://localhost:3306/" + db;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.c = DriverManager.getConnection(url, un, pwd);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			System.out.println("1");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("2");
			e.printStackTrace();
		}
	}
	
	public boolean checkdb(String n, String p){
		String query = "select * from User where email=? and password=?";
		try {
			PreparedStatement ps = c.prepareStatement(query);
			ps.setString(1, n);
			ps.setString(2, p);
			ResultSet resultSet = ps.executeQuery();
			this.results = resultSet.first();
		} catch (SQLException e) {
			System.out.println("3");
			e.printStackTrace();
		}
		return results;
	}

}
