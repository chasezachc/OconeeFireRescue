package model;

import java.sql.Date;

public class PersonCertificate {

	private int eID;
	private int cID;
	private Date lastRenewed;
	
	public PersonCertificate() {
	}
	/**
	 * @return the eID
	 */
	public int geteID() {
		return eID;
	}
	/**
	 * @param eID the eID to set
	 */
	public void seteID(int eID) {
		this.eID = eID;
	}
	/**
	 * @return the cID
	 */
	public int getcID() {
		return cID;
	}
	/**
	 * @param cID the cID to set
	 */
	public void setcID(int cID) {
		this.cID = cID;
	}
	/**
	 * @return the lastRenewed
	 */
	public Date getLastRenewed() {
		return lastRenewed;
	}
	/**
	 * @param lastRenewed the lastRenewed to set
	 */
	public void setLastRenewed(Date lastRenewed) {
		this.lastRenewed = lastRenewed;
	}
	/**
	 * 
	 */
	
	
	
	
}
