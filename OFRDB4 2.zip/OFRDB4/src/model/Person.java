package model;

import java.util.Date;

public class Person {
	
	private String firstName;
	private String lastName;
	private String radioNumber;
	private String stationNumber;
	private String isActive;
	private String address;
	private int workPhone;
	private int mobilePhone;
	private int employeeID;
	private String gender;
	private String position;
	private String email;
	private String dob;
	private Certificate[] certificates;
	/**
	 * @param firstName
	 * @param lastName
	 * @param radioNumber
	 * @param stationNumber
	 * @param isActive
	 * @param address
	 * @param workPhone
	 * @param mobilePhone
	 * @param employeeID
	 * @param certificates
	 */
	
	public Person(){
	}
	
	public Person(String sn, String rn, String email){
		this.stationNumber=sn;
		this.radioNumber=rn;
		this.email=email;
		
	}
	
	public Person(String firstName, String lastName, String radioNumber, String stationNumber, String isActive,
			String address, int workPhone, int mobilePhone, int employeeID, Certificate[] certificates) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.radioNumber = radioNumber;
		this.stationNumber = stationNumber;
		this.isActive = isActive;
		this.address = address;
		this.workPhone = workPhone;
		this.mobilePhone = mobilePhone;
		this.employeeID = employeeID;
		this.certificates = certificates;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the radioNumber
	 */
	public String getRadioNumber() {
		return radioNumber;
	}
	/**
	 * @param radioNumber the radioNumber to set
	 */
	public void setRadioNumber(String radioNumber) {
		this.radioNumber = radioNumber;
	}
	/**
	 * @return the stationNumber
	 */
	public String getStationNumber() {
		return stationNumber;
	}
	/**
	 * @param stationNumber the stationNumber to set
	 */
	public void setStationNumber(String stationNumber) {
		this.stationNumber = stationNumber;
	}
	/**
	 * @return the isActive
	 */
	public String isActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(String isActive) {
		this.isActive = isActive;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the workPhone
	 */
	public int getWorkPhone() {
		return workPhone;
	}
	/**
	 * @param workPhone the workPhone to set
	 */
	public void setWorkPhone(int workPhone) {
		this.workPhone = workPhone;
	}
	/**
	 * @return the mobilePhone
	 */
	public int getMobilePhone() {
		return mobilePhone;
	}
	/**
	 * @param mobilePhone the mobilePhone to set
	 */
	public void setMobilePhone(int mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	/**
	 * @return the employeeID
	 */
	public int getEmployeeID() {
		return employeeID;
	}
	/**
	 * @param employeeID the employeeID to set
	 */
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	/**
	 * @return the certificates
	 */
	public Certificate getCertificates(int i) {
		return certificates[i];
	}
	/**
	 * @param certificates the certificates to set
	 */
	public void setCertificates(Certificate[] certificates) {
		this.certificates = certificates;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}

	/**
	 * @param position the position to set
	 */
	public void setPosition(String position) {
		this.position = position;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

}
