package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteCQuery {
	
	private Connection c;

	public DeleteCQuery(String db, String un, String pwd){
		String url = "jdbc:mysql://localhost:3306/" + db;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.c = DriverManager.getConnection(url, un, pwd);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void delete(int eID, int cID){
		String query = "delete from Person_Certificate where employeeID=? and certificateID=?";
		try {
			PreparedStatement ps = c.prepareStatement(query);
			ps.setInt(1, eID);
			ps.setInt(2, cID);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
