package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Person;

public class ReadMQuery {
	
	private Connection c;
	int eID;
	ResultSet results;
	private Person person = new Person();
	
	public ReadMQuery(String dbname, String uname, String password, int eID){
		String url = "jdbc:mysql://localhost:3306/" + dbname;
		this.eID = eID;
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.c = DriverManager.getConnection(url, uname, password);
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Person getPerson(){
		String query = "select * from Person where employeeID= ?";
		try {
			PreparedStatement ps = c.prepareStatement(query);
			ps.setInt(1, this.eID);
			this.results = ps.executeQuery();
			this.results.next();
			person.setEmployeeID(this.results.getInt("employeeID"));
			person.setFirstName(this.results.getString("firstName"));
			person.setLastName(this.results.getString("lastName"));
			person.setRadioNumber(this.results.getString("radioNumber"));
			person.setStationNumber(this.results.getString("stationNumber"));
			person.setActive(this.results.getString("active"));
			person.setAddress(this.results.getString("address"));
			person.setWorkPhone(this.results.getInt("workPhone"));
			person.setMobilePhone(this.results.getInt("mobilePhone"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this.person;
	}

}
