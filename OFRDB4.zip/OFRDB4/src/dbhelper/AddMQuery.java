package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Person;

public class AddMQuery {
	
	private Connection c;

	public AddMQuery(String db, String un, String pwd){
		String url = "jdbc:mysql://localhost:3306/" + db;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.c = DriverManager.getConnection(url, un, pwd);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			System.out.println("1");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("2");
			e.printStackTrace();
		}
	}
	
	public void addM(Person person){
		String query = "insert into Person (firstName, lastName, radioNumber,"
				+ " stationNumber, active, address, workPhone, mobilePhone)"
				+ " values (?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement ps = c.prepareStatement(query);
			ps.setString(1, person.getFirstName());
			ps.setString(2, person.getLastName());
			ps.setString(3, person.getRadioNumber());
			ps.setString(4, person.getStationNumber());
			ps.setString(5, person.isActive());
			ps.setString(6, person.getAddress());
			ps.setInt(7, person.getWorkPhone());
			ps.setInt(8, person.getMobilePhone());
			ps.executeUpdate(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
