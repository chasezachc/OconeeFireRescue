package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteMQuery {
	
	private Connection c;

	public DeleteMQuery(String db, String un, String pwd){
		String url = "jdbc:mysql://localhost:3306/" + db;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.c = DriverManager.getConnection(url, un, pwd);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void delete(int eID){
		String query1 = "delete from Person_Certificate where employeeID=?";
		String query2 = "delete from Person where employeeID=?";
		try {
			PreparedStatement ps1 = c.prepareStatement(query1);
			PreparedStatement ps2 = c.prepareStatement(query2);
			ps1.setInt(1, eID);
			ps2.setInt(1, eID);
			ps1.executeUpdate();
			ps2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
