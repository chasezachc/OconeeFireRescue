package dbhelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class LastRenewedQuery {

	private Connection c;
	
	public LastRenewedQuery(String db, String un, String pwd){
		String url = "jdbc:mysql://localhost:3306/" + db;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			this.c = DriverManager.getConnection(url, un, pwd);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			System.out.println("1");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("2");
			e.printStackTrace();
		}
	}

	public void getDate(int eID, int cID){
		String query = "select * from Person_Certificate where employeeID=? and certificateID=?";
		PreparedStatement ps;
		try {
			System.out.println("Right before it!");
			ps = c.prepareStatement(query);
			ps.setInt(1, eID);
			ps.setInt(2, cID);
			System.out.println("Right before it!");
			ResultSet results = ps.executeQuery();
			System.out.println("Right before it!");
			System.out.println(results.getDate("lastRenewed"));
			System.out.println("Right before it!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//return date;
	}
	
}
